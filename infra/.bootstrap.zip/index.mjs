export const handler = async () => ({ statusCode: 503, body: 'no bundle deployed yet' });
